Python 3.12.1 (v3.12.1:2305ca5144, Dec  7 2023, 17:23:39) [Clang 13.0.0 (clang-1300.0.29.30)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> from ultralytics import YOLO
... from ultralytics.models.yolo.detect.predict import DetectionPredictor
... import cv2
... import numpy as np
... 
... # Charger le modèle YOLO
... model = YOLO("yolov8s.pt")
... 
... # Définir la source de la caméra (0 pour la caméra par défaut, remplacez par l'adresse IP pour une caméra réseau)
... camera_source = 0
... 
... # Ouvrir la connexion à la caméra
... cap = cv2.VideoCapture(camera_source)
... 
... # Vérifier si la caméra est ouverte correctement
... if not cap.isOpened():
...     print("Erreur: Impossible d'ouvrir la caméra.")
...     exit()
... 
... try:
...     while True:
...         # Lire une image de la caméra
...         ret, frame = cap.read()
... 
...         if not ret:
...             print("Erreur: Impossible de lire l'image depuis la caméra.")
...             break
... 
...         # Prédire avec le modèle YOLO
...         results = model.predict(images=[frame], show=False)
... 
...         # Extraire les coordonnées des boîtes englobantes des objets détectés par YOLO
...         bboxes = results.xyxy[0].cpu().numpy()
... 
...         # Convertir l'image en niveaux de gris pour la détection des cercles
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Appliquer un filtre Gaussien pour améliorer la détection des cercles
        gray_frame = cv2.GaussianBlur(gray_frame, (9, 9), 2)

        # Détecter les cercles dans l'image
        circles = cv2.HoughCircles(
            gray_frame,
            cv2.HOUGH_GRADIENT,
            dp=1,
            minDist=50,
            param1=50,
            param2=30,
            minRadius=10,
            maxRadius=50
        )

        # Si des cercles sont détectés, dessinez-les sur l'image
        if circles is not None:
            circles = np.uint16(np.around(circles))
            for i in circles[0, :]:
                cv2.circle(frame, (i[0], i[1]), i[2], (0, 255, 0), 2)

        # Dessiner les boîtes englobantes des objets détectés par YOLO
        for bbox in bboxes:
            cv2.rectangle(frame, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (0, 255, 0), 2)

        # Afficher les résultats
        cv2.imshow("Object Detection with Circles", frame)

        # Arrêter la boucle si la touche 'q' est enfoncée
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    # Libérer les ressources lorsque la boucle est terminée
    cap.release()
    cv2.destroyAllWindows()
