#include <Servo.h>
#include <math.h>

// Définition des pins des servomoteurs
#define BASE_SERVO_PIN 8
#define SHOULDER_SERVO_PIN 9
#define ELBOW_SERVO_PIN 10
#define WRIST_SERVO_PIN 11
#define GRIPPER_SERVO_PIN 12

// Longueurs des segments du bras robot
const float L1 = 10.5;
const float L2 = 11.3;
const float L3 = 11.0;
const float L4 = 5.0;
const float L5 = 5.0;

Servo baseServo;
Servo shoulderServo;
Servo elbowServo;
Servo wristServo;
Servo gripperServo;

void moveArm(float x, float y, float z);
void inverseKinematics(float x, float y, float z, float &baseAngle, float &shoulderAngle, float &elbowAngle, float &wristAngle, float &gripperAngle);

void setup() {
  baseServo.attach(BASE_SERVO_PIN);
  shoulderServo.attach(SHOULDER_SERVO_PIN);
  elbowServo.attach(ELBOW_SERVO_PIN);
  wristServo.attach(WRIST_SERVO_PIN);
  gripperServo.attach(GRIPPER_SERVO_PIN);

  Serial.begin(9600);
  Serial.println("Bras robot prêt !");
}

void loop() {
  int pickAndPlacePositions[4][3] = {
    {10, 10, 10},
    {15, 15, 15},
    {10, 10, 10},
    {10, 0, 0}
  };

  for (int t = 0; t < 4; t++) {
    moveArm(pickAndPlacePositions[t][0], pickAndPlacePositions[t][1], pickAndPlacePositions[t][2]);

    if (t == 1)
      gripperServo.write(180);
    else if (t == 3)
      gripperServo.write(0);

    delay(3000); // Attente après l'action de la pince

    if (t != 3)
      gripperServo.write(0);

    delay(700);
  }
}

void moveArm(float x, float y, float z) {
  float baseAngle, shoulderAngle, elbowAngle, wristAngle, gripperAngle;
  inverseKinematics(x, y, z, baseAngle, shoulderAngle, elbowAngle, wristAngle, gripperAngle);

  baseServo.write(baseAngle);
  shoulderServo.write(shoulderAngle);
  elbowServo.write(elbowAngle);
  wristServo.write(wristAngle);
  gripperServo.write(gripperAngle);

  delay(2000);
}

void inverseKinematics(float x, float y, float z, float &baseAngle, float &shoulderAngle, float &elbowAngle, float &wristAngle, float &gripperAngle) {
  // ... (votre code de cinématique inverse ici)
}
